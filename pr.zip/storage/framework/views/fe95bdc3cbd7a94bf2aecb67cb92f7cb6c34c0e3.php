

<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>

<body>

<table id="myTable" class="table table-hover table-product" style="width:100%">
    <thead>
        <tr>
            <th>Event date</th>
            <th>Image</th>
            <th>Description</th>
            <th>Photo Description</th>
            <th>Key Event</th>
            <th></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($event->event_date); ?></td>
            <td>
                <?php if($event->image): ?>
                    <img src="<?php echo e(asset('uploads/event/' . $event->image)); ?>" alt="Event Image" class="templatemo-item" style="max-width: 100px;">
                <?php else: ?>
                    No Image
                <?php endif; ?>
            </td>
            <td><?php echo e($event->description); ?></td>
            <td><?php echo e($event->photo_description); ?></td>
            <td><?php echo e($event->key_event ? 'Yes' : 'No'); ?></td>
            <td>
              <div class="dropdown">
                <a class="dropdown-toggle" role="button" 
                  data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-display="static">Action
                </a>

                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="dropdownMenuLink">
                  <a href="/admin/edit-event/${event.id}" class="dropdown-item">Edit</a>
                  <a href="/admin/delete-event/${event.id}" class="dropdown-item">Delete</a>
                  <a class="dropdown-item" href="#">Something else here</a>
                </div>
              </div>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
<script src="//cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
<script>
let table = new DataTable('#myTable');
</script>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\дз\4 курс\курсова\pr\resources\views/admin/event/index.blade.php ENDPATH**/ ?>