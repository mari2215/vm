

<?php $__env->startSection('content'); ?>

<style>
 

</style>
<h1>Add event</h1>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            
            <div class="card mt-4">
                <div class="card-header">
                <h3>Add event</h3>
                </div>
                <div class="card-body">
                    <form class = "" action="<?php echo e(url('admin/add-event')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="my-1">
                            <label for="event_date">Event Date:</label>
                            <input type="date" id="event_date" name="event_date" class="form-control">
                        </div>

                        <div class="my-1">
                            <label for="description">Description:</label>
                            <textarea id="description" name="description" class="form-control" rows="4"></textarea>
                        </div>

                        <div class="my-1">
                            <label for="image">Event Image:</label>
                            <input type="file" id="image" name="image" class="form-control">
                        </div>

                        <div class="my-1">
                            <label for="photo_description">Image Description:</label>
                            <textarea id="photo_description" name="photo_description" class="form-control" rows="4"></textarea>
                        </div>

                        <div class="my-1">
                            <label for="key_event">Is Key Event:</label>
                            <input type="checkbox" id="key_event" name="key_event" value="1">
                        </div>

                        <button type="submit" class="btn btn-primary">Submit</button>

                    </form>
                </div>
            </div>

        </div>
    </div>


</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\дз\4 курс\курсова\pr\resources\views/admin/event/create.blade.php ENDPATH**/ ?>