

<?php $__env->startSection('content'); ?>

<?php if(session('message')): ?>
        <div class="alert alert-success"><?php echo e(session('message')); ?></div>
        <?php endif; ?>

<body>
<div class="container">
    <div class="row">
      <div class="col-lg-12">
        <div class="page-content">
            <form action="<?php echo e(url('admin/update-event/'.$event->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="my-1">
                    <label for="event_date">Event Date:</label>
                    <input type="date" id="event_date" name="event_date" value="<?php echo e($event->event_date); ?>" class="form-control">
                    <p>Current Date: <?php echo e($event->event_date); ?></p>
                </div>


                <div class="my-1">
                    <label for="description">Description:</label>
                    <textarea id="description" name="description" class="form-control" rows="4"><?php echo e($event->description); ?></textarea>
                </div>

                <div class="my-1">
                    <label for="image">Event Image:</label>
                    <input type="file" id="image" name="image" class="form-control">
                    <p>Current Image: 
                        <?php if($event->image): ?>
                            <img src="<?php echo e(asset('uploads/event/' . $event->image)); ?>" alt="Event Image" style="max-width: 100px;">
                        <?php else: ?>
                            No Image
                        <?php endif; ?>
                    </p>
                </div>

                <div class="my-1">
                    <label for="photo_description">Image Description:</label>
                    <textarea id="photo_description" name="photo_description" class="form-control" rows="4"><?php echo e($event->photo_description); ?></textarea>
                </div>

                <div class="my-1">
                    <label for="key_event">Is Key Event:</label>
                    <input type="checkbox" id="key_event" name="key_event" value="1" <?php if($event->key_event): ?> checked <?php endif; ?>>
                </div>

                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
 

        </div>
      </div>
    </div>
  </div>
</body>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\дз\4 курс\курсова\pr\resources\views/admin/event/edit.blade.php ENDPATH**/ ?>