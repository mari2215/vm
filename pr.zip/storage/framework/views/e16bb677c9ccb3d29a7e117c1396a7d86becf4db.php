<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(Auth::user()->name); ?>

                    <br>
                    <?php echo e($msg); ?>


                    <?php if(Auth::user()->role === 'admin'): ?>
                        <a class="btn btn-main" href="<?php echo e(url('admin/add-event')); ?>">Add Event</a>
                        <a class="btn btn-main" href="<?php echo e(url('admin/event')); ?>">View Event</a>
                        <button class="btn btn-main">Admin Button</button>
                    <?php endif; ?>

                <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\дз\4 курс\курсова\pr\resources\views/home.blade.php ENDPATH**/ ?>