<?php

namespace App\Http\Controllers\Admin;

use App\Models\Event;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\EventFormRequest;
use App\Http\Requests\Admin\EventUpdateRequest;

class EventController extends Controller
{
    public function index(){

        $events = Event::all();
        return view('admin.event.index', compact('events'));
    }

    public function home(){
        $events = Event::all();
        return view('admin.home', compact('events'));
    }

    public function getEvents()
    {
        $events = Event::all(); // Отримайте всі об'єкти подій
    
        return response()->json($events);
    }

    public function create(){
        return view('admin.event.create');
    }

    public function store(EventFormRequest $request)
    {
        $data = $request->validated();
        $event = new Event;
        $event->event_date = $data['event_date'];
        $event->description = $data['description'];
        $event->photo_description = $data['photo_description'];
        $event->key_event = isset($data['key_event']) ? 1 : 0;

       
        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time().'.'.$file->getClientOriginalExtension();
            $file->move('uploads/event/', $filename);
            $event->image = $filename;
        }
        $event->save();
        return redirect('admin/event')->with('message', 'Event created successfully');
    }

    public function edit($event_id)
    {
        $event = Event::find($event_id);

        return view('admin.event.edit', compact('event'));
    }

    public function delete($event_id)
    {
        $event = Event::find($event_id);
        if($event){
            $event->delete();
            return redirect('admin/event')->with('message', 'Event deleted');
        }
        else{
            return redirect('admin/event')->with('message', 'event not deleted');
        }

        
    }

    public function update(EventUpdateRequest $request, $event_id)
    {
        $data = $request->validated();
        $event = Event::find($event_id);

        if (!$event) {
            return redirect('admin/event')->with('error', 'Event not found');
        }

        if ($request->hasFile('image')) {
            $file = $request->file('image');
            $filename = time() . '.' . $file->getClientOriginalExtension();
            $file->move('uploads/event/', $filename);
            $event->image = $filename;
        }

        // Check if the event date or description has changed
        if ($data['event_date'] != null && $event->event_date != $data['event_date']) {
            $event->event_date = $data['event_date'];
        }
        
        $event->description = $data['description'];
        $event->photo_description = $data['photo_description'];
        $event->key_event = isset($data['key_event']) ? 1 : 0;

        $event->save();

        return redirect('admin/event')->with('message', 'Event updated successfully');
    }
}
