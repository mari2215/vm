<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Auth::routes();

//user
// Route::middleware(['auth', 'user-role:user'])->group(function(){
//     Route::get("/home", [HomeController::class, 'userHome'])->name('home');
// });

//admin
// Route::middleware(['auth', 'user-role:admin'])->group(function(){
//     Route::get("/admin/home", [HomeController::class, 'adminHome'])->name('home.admin');
// });
Route::prefix('user')->middleware(['auth', 'user-role:user'])->group(function(){
    
    Route::get("/home", [HomeController::class, 'userHome'])->name('home');
   
});

Route::prefix('admin')->middleware(['auth', 'user-role:admin'])->group(function(){
    // Route::get("home", [HomeController::class, 'adminHome'])->name('home');
    Route::get('home', [App\Http\Controllers\Admin\EventController::class, 'home'] );
    Route::get('event', [App\Http\Controllers\Admin\EventController::class, 'index'] );
    Route::get('add-event', [App\Http\Controllers\Admin\EventController::class, 'create'] );
    Route::post('add-event', [App\Http\Controllers\Admin\EventController::class, 'store'] );
    Route::get('edit-event/{event_id}', [App\Http\Controllers\Admin\EventController::class, 'edit'] );
    Route::put('update-event/{event_id}', [App\Http\Controllers\Admin\EventController::class, 'update'] );
    Route::get('delete-event/{event_id}', [App\Http\Controllers\Admin\EventController::class, 'delete'] );
    // routes/web.php

    Route::get('get-events', [App\Http\Controllers\Admin\EventController::class, 'getEvents']);

});

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
